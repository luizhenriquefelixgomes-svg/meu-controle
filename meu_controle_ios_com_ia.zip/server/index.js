import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";

const app = express();
app.set("trust proxy", 1);
app.use(helmet());
app.use(express.json({ limit: "24kb" }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: "draft-7", legacyHeaders: false }));
const port = process.env.PORT || 3000;
const client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;
const allowedOrigin = process.env.APP_ORIGIN;
app.use((req,res,next)=>{
  const origin=req.headers.origin;
  if (allowedOrigin && origin===allowedOrigin) {
    res.setHeader("Access-Control-Allow-Origin", allowedOrigin);
    res.setHeader("Vary","Origin");
    res.setHeader("Access-Control-Allow-Headers","Content-Type");
    res.setHeader("Access-Control-Allow-Methods","POST, OPTIONS");
  }
  if(req.method==="OPTIONS") return res.sendStatus(204);
  next();
});
app.get("/health",(_req,res)=>res.json({ok:true,service:"meu-controle-api"}));
app.post("/api/finance-assistant", async (req,res)=>{
  if(!client) return res.status(503).json({error:"Servidor sem OPENAI_API_KEY configurada."});
  const {question,summary}=req.body||{};
  if(typeof question!=="string"||!question.trim()||question.length>3000) return res.status(400).json({error:"Envie uma pergunta válida (até 3.000 caracteres)."});
  if(!summary||typeof summary!=="object") return res.status(400).json({error:"Resumo financeiro ausente."});
  try{
    const response=await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.4-mini",
      instructions: `Você é o assistente do aplicativo Meu Controle, fala português brasileiro de forma direta, respeitosa e prática. Ajude a organizar orçamento, dívidas, fluxo de caixa e metas. Use somente os números fornecidos; nunca invente renda, taxas, datas ou saldo. Diferencie fatos de estimativas. Para dívidas, explique que a estratégia avalanche (maior juros primeiro) costuma reduzir juros totais, mas priorize contas essenciais e riscos imediatos quando necessário. Não recomende deixar de pagar despesas essenciais, tomar empréstimo arriscado ou fazer investimento específico. Não prometa resultados. Faça um plano em passos curtos e pergunte dados que faltam quando forem decisivos. Não solicite senhas, códigos ou dados bancários sigilosos.`,
      input: `Pergunta do usuário:\n${question.trim()}\n\nResumo financeiro informado pelo usuário (dados podem estar incompletos):\n${JSON.stringify(summary)}`
    });
    res.json({answer:response.output_text || "Não consegui gerar uma resposta útil. Tente reformular a pergunta."});
  }catch(err){
    console.error("AI request failed",err?.status||"",err?.message||"");
    res.status(502).json({error:"A IA não respondeu agora. Tente novamente mais tarde."});
  }
});
app.listen(port,()=>console.log(`Meu Controle API ouvindo na porta ${port}`));
