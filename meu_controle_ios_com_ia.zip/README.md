# Meu Controle — projeto iPhone (PWA) + API de IA

## O que está incluído
- `public/`: aplicativo responsivo para iPhone, com estilo premium minimalista.
- Receitas, despesas, categorias e histórico.
- Cadastro de dívidas, parcelas, vencimentos e taxa de juros informada.
- Metas com progresso.
- Backup JSON e exclusão de dados locais.
- `server/`: API Node.js que chama a API da OpenAI sem expor a chave no navegador.

## Arquitetura
- Frontend: HTML/CSS/JavaScript, instalável como PWA pelo Safari.
- Persistência: `localStorage` no iPhone. Os dados não são sincronizados e podem ser apagados se o usuário limpar os dados do Safari. Faça backups.
- IA: navegador envia pergunta e resumo financeiro para um backend HTTPS; backend usa `OPENAI_API_KEY` em variável de ambiente. A chave nunca deve ir para o frontend.
- Hospedagem: publique `public/` num host estático HTTPS e `server/` num serviço Node HTTPS. Restrinja `APP_ORIGIN` ao endereço exato do frontend.

## Para ativar a IA online
1. Crie uma chave da API OpenAI na sua conta de API. A cobrança da API é separada da assinatura ChatGPT.
2. Hospede `server/` em um provedor que rode Node.js 20+.
3. Configure as variáveis no serviço:
   - `OPENAI_API_KEY`: sua chave secreta
   - `OPENAI_MODEL`: modelo disponível na sua conta (padrão configurado: `gpt-5.4-mini`; troque se necessário)
   - `APP_ORIGIN`: origem HTTPS exata do frontend, por exemplo `https://seu-app.exemplo.com`
   - `PORT`: normalmente o host define isso automaticamente
4. Instale dependências e rode:
   ```bash
   npm install
   npm start
   ```
5. No arquivo `public/index.html`, substitua `window.MEU_CONTROLE_API||''` por uma URL HTTPS do backend, por exemplo:
   ```js
   const API_BASE='https://sua-api.exemplo.com';
   ```
   Ou defina `window.MEU_CONTROLE_API` antes do código principal.
6. Faça deploy do frontend novamente. Teste `https://sua-api.exemplo.com/health` e faça uma pergunta na tela Assistente.

## Instalar no iPhone
1. Publique a pasta `public/` num endereço HTTPS.
2. Abra esse endereço no Safari do iPhone.
3. Toque em Compartilhar → Adicionar à Tela de Início → Adicionar.
4. Abra pelo ícone criado.

## Importante: o que ainda não está feito
- Este ZIP não é um `.ipa` assinado nem está publicado na App Store. Compilar um app nativo iOS requer Xcode/macOS e assinatura Apple.
- A IA online não funciona até a API ser hospedada e receber uma chave válida.
- O armazenamento local não é criptografia de nível bancário; o app não acessa bancos nem faz sincronização.
- Não coloque segredos, senhas bancárias ou números completos de cartão no app.
- Para produção: autenticação se houver nuvem, política de privacidade, revisão de segurança, testes em iOS real e monitoramento de custos.

## Teste local
Sirva a pasta `public` com qualquer servidor estático local. Para testar instalação PWA e service worker, use HTTPS ou `localhost`.
